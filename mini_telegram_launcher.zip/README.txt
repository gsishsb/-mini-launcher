MINI LAUNCHER ДЛЯ TELEGRAM — стартовый комплект

Что умеет:
- Telegram-бот показывает кнопку «Открыть лаунчер».
- Mini App открывает страницу с сеткой ссылок.
- Можно добавлять и удалять ссылки.
- Ссылки сохраняются в localStorage браузера на этом устройстве.

ВАЖНО:
Это минимальный рабочий прототип, не замена домашнего экрана iPhone.
Для Telegram Mini App странице нужен публичный HTTPS-адрес.
В этой версии настройки не синхронизируются между устройствами.

1. Создай бота:
   - Открой @BotFather в Telegram.
   - Отправь /newbot и следуй инструкциям.
   - Скопируй токен.

2. Опубликуй index.html на HTTPS-хостинге:
   - Например, GitHub Pages или другой статический хостинг.
   - Получи публичный адрес страницы.
   - В BotFather настрой домен Web App, если Telegram попросит.

3. Установи Python 3.10+ и зависимость:
   pip install python-telegram-bot

4. Укажи переменные окружения и запусти:
   Linux/macOS:
     export BOT_TOKEN="ТОКЕН_ОТ_BOTFATHER"
     export WEBAPP_URL="https://твой-сайт.example/"
     python bot.py

   Windows PowerShell:
     $env:BOT_TOKEN="ТОКЕН_ОТ_BOTFATHER"
     $env:WEBAPP_URL="https://твой-сайт.example/"
     python bot.py

5. Открой своего бота и отправь /start.

Не публикуй токен бота и не отправляй его посторонним.
