import os
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo
from telegram.ext import Application, CommandHandler, ContextTypes

BOT_TOKEN = os.getenv("BOT_TOKEN", "PASTE_YOUR_BOT_TOKEN_HERE")
WEBAPP_URL = os.getenv("WEBAPP_URL", "https://YOUR-HTTPS-SITE.example")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [[InlineKeyboardButton(
        "🚀 Открыть лаунчер",
        web_app=WebAppInfo(url=WEBAPP_URL)
    )]]
    await update.message.reply_text(
        "📱 Добро пожаловать в Mini Launcher!\n\n"
        "Открой лаунчер кнопкой ниже. Добавленные ссылки сохраняются "
        "в браузере этого устройства.",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

def main():
    if BOT_TOKEN == "PASTE_YOUR_BOT_TOKEN_HERE":
        raise RuntimeError("Сначала укажи BOT_TOKEN в переменных окружения.")
    if "YOUR-HTTPS-SITE" in WEBAPP_URL:
        raise RuntimeError("Сначала укажи WEBAPP_URL — публичный HTTPS-адрес index.html.")
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    print("Бот запущен. Нажми Ctrl+C для остановки.")
    app.run_polling()

if __name__ == "__main__":
    main()
